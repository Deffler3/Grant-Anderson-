﻿using OutputFactory;

namespace HelloWorld
{
    internal sealed class Hello
    {
        private static void Main()
        {
            var helloOutput = HelloOutputFactory.Create();
            helloOutput.WriteMessage();
        }
    }
}
