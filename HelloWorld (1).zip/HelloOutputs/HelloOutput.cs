﻿using System;
using Infrastructure;

namespace HelloOutputs
{
    public abstract class HelloOutput : IHelloOutput
    {
        protected const string OutputMessage = "Hello World";

        public virtual void WriteMessage()
        {
#if DEBUG
            Console.WriteLine($"Base class implementation of WriteMessage() called on class {this.GetType()}.");
#else
            Console.WriteLine("Unknown output format.");
#endif

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}