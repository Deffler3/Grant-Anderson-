﻿namespace HelloOutputs
{
    public sealed class UndefinedOutput : HelloOutput
    {
    }
}