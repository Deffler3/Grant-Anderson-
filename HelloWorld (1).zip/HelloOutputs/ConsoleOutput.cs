﻿using System;

namespace HelloOutputs
{
    public sealed class ConsoleOutput : HelloOutput
    {
        public override void WriteMessage()
        {
            Console.WriteLine(HelloOutput.OutputMessage);

            // Keep the console window open when debugger is attached.
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}