﻿namespace Infrastructure
{
    public interface IHelloOutput
    {
        void WriteMessage();
    }
}