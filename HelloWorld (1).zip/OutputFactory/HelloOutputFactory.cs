﻿using System;
using System.Collections.Generic;
using HelloOutputs;
using Infrastructure;

namespace OutputFactory
{
    public sealed class HelloOutputFactory
    {
        private static readonly Dictionary<OutputTypes, IHelloOutput> OutputTypeToHelloOutput = new Dictionary<OutputTypes, IHelloOutput>
        {
            [OutputTypes.Undefined] = new UndefinedOutput(),
            [OutputTypes.Console] = new ConsoleOutput()
        };

        public static IHelloOutput Create()
        {
            var outputSelectionContract = JsonSerializer.DeserializeJsonFile();
            if (outputSelectionContract == null)
            {
                return HelloOutputFactory.OutputTypeToHelloOutput[OutputTypes.Undefined];
            }

            OutputTypes outputType;
            var parseSuccessful = Enum.TryParse(outputSelectionContract.OutputType, true, out outputType);
            return HelloOutputFactory.OutputTypeToHelloOutput[parseSuccessful ? outputType : OutputTypes.Undefined];
        }
    }
}
