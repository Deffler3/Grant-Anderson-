﻿namespace OutputFactory
{
    internal enum OutputTypes
    {
        Undefined,
        Console
    }
}