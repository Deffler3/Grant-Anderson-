﻿using System.Runtime.Serialization;

namespace OutputFactory
{
    [DataContract]
    public sealed class OutputSelectionJsonDataContract
    {
        [DataMember]
        public string OutputType;
    }
}