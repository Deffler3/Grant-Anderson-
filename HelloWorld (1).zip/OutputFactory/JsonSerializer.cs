﻿using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Json;

namespace OutputFactory
{
    public sealed class JsonSerializer
    {
        public static OutputSelectionJsonDataContract DeserializeJsonFile()
        {
            var dcjs = new DataContractJsonSerializer(typeof(OutputSelectionJsonDataContract));
            var configurationFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\HelloWorldConfig.json";
            if (!File.Exists(configurationFile))
            {
                return null;
            }

            var stream = new MemoryStream(File.ReadAllBytes(configurationFile));

            try
            {
                return (OutputSelectionJsonDataContract)dcjs.ReadObject(stream);
            }
            catch
            {
                return null;
            }
        }
    }
}